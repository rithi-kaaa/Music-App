package com.example.musicophileredo;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

public class PlaySong extends AppCompatActivity {

    private String title = "";
    private String artiste = "";
    private String fileLink = "";
    private int drawable;
    private int currentIndex = -1;

    private MediaPlayer player = new MediaPlayer();
    private Button btnPlayPause = null;
    private SongCollection songCollection = new SongCollection();

    SeekBar seekbar;
    Handler handler = new Handler();

    Button shuffleBtn;
    Boolean shuffleFlag = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_song);
        btnPlayPause = findViewById(R.id.btnPlayPause);
        Handler handler = new Handler();

        Bundle songData = this.getIntent().getExtras();
        currentIndex = songData.getInt("index");
        Log.d("temasek", "Retrieved Position  : " + currentIndex);
        displaySongBasedOnIndex();
        Log.d("temasek", "Retrieved Position : " + currentIndex);
        playSong(fileLink);
        Log.d("temasek", "Retrieved Position1 : " + currentIndex);

        seekbar = findViewById(R.id.seekBar);
        seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (player != null && player.isPlaying()) {
                    player.seekTo(seekBar.getProgress());

                }

            }
        });

    }

    Runnable p_bar = new Runnable() {
        @Override
        public void run() {
            if (player != null && player.isPlaying()) {
                seekbar.setProgress(player.getCurrentPosition());

            }
            handler.postDelayed(this, 1000);
        }
    };

    public void displaySongBasedOnIndex() {

        Song song = songCollection.getCurrentSong(currentIndex);

        title = song.getTitle();
        artiste = song.getArtiste();
        fileLink = song.getFileLink();
        drawable = song.getDrawable();
        TextView txtTitle = findViewById(R.id.txtSongTitle);
        txtTitle.setText(title);
        TextView txtArtiste = findViewById(R.id.txtArtist);
        txtArtiste.setText(artiste);
        ImageView iCoverArt = findViewById(R.id.imgCoverArt);
        iCoverArt.setImageResource(drawable);

        ImageView shuffleBtn = findViewById(R.id.shuffleBtn);
        shuffleBtn.setImageResource(drawable);


    }

    public void playSong(String songUrl) {
        try {
            player.reset();
            player.setDataSource(songUrl);
            player.prepare();
            player.start();
            gracefullyStopsWhenMusicEnds();

            btnPlayPause.setText("PAUSE");
            setTitle(title);

        } catch (IOException e) {
            e.printStackTrace();

        }

    }

    public void playOrPauseMusic(View view) {

        if (player.isPlaying()) {
            player.pause();
            btnPlayPause.setText("PLAY");
            seekbar.setMax(player.getDuration());
            handler.removeCallbacks(p_bar);
            handler.postDelayed(p_bar, 1000);
            Log.d("temasek", "running");
        } else {
            player.start();
            btnPlayPause.setText("Pause");
        }
    }

    private void gracefullyStopsWhenMusicEnds() {
        player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                Toast.makeText(getBaseContext(), "The song had ended and the onCompleteListener is activated\n" +
                        "The button text is changed to 'PLAY' ", Toast.LENGTH_LONG).show();
                btnPlayPause.setText("PLAY");
            }
        });
    }

    public void playNext(View view) {
        currentIndex = songCollection.getNextSong(currentIndex);
        Toast.makeText(this, "After Clicking playNext\nthe current index of this song\n " +
                "in the songCollection array is now :" + currentIndex, Toast.LENGTH_LONG).show();
        Log.d("temasek", "After playNext, the index is now :" + currentIndex);
        displaySongBasedOnIndex();
        playSong(fileLink);
    }

    public void playPrevious(View view) {
        currentIndex = songCollection.getPrevSong(currentIndex);
        Toast.makeText(this, "After Clicking playNext\nthe current index of this song\n " +
                "in the songCollection array is now :" + currentIndex, Toast.LENGTH_LONG).show();
        displaySongBasedOnIndex();
        playSong(fileLink);
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if (player != null) {
            handler.removeCallbacks(p_bar);
            player.stop();
            player.release();
            player = null;

        }

    }


}