package com.example.musicophileredo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class Album2Activity extends AppCompatActivity {
    SongCollection songCollection = new SongCollection();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_album2);

    }

    public void handleSelection1(View view) {
        String resourceId = getResources().getResourceEntryName(view.getId());
        int currentArrayIndex = songCollection.searchSongById(resourceId);
        Log.d("temasek", "the current array position is : " + currentArrayIndex);
        sendDataToActivity1(currentArrayIndex);
    }

    public void sendDataToActivity1(int index) {
        Intent intent = new Intent(this, PlaySong.class);
        intent.putExtra("index", index);
        startActivity(intent);
    }
}