package com.example.musicophileredo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    SongCollection songCollection = new SongCollection();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void handleSelection(View view) {
        String resourceId = getResources().getResourceEntryName(view.getId());
        int currentArrayIndex = songCollection.searchSongById(resourceId);
        Log.d("temasek", "the current array position is : " + currentArrayIndex);
        sendDataToActivity(currentArrayIndex);
    }

    public void sendDataToActivity(int index){
        Intent intent = new Intent(this,PlaySong.class);
        intent.putExtra("index",index);
        startActivity(intent);
    }
    public void handleSelection1 ( View view){
        String resourceId = getResources().getResourceEntryName(view.getId());
        int currentArrayIndex = songCollection.searchSongById(resourceId);
        Log.d("temasek", "the current array position is : " + currentArrayIndex);
        sendDataToActivity1(currentArrayIndex);
    }
    public void sendDataToActivity1( int index){
        Intent intent = new Intent(this, PlaySong.class);
        intent.putExtra("index", index);
        startActivity(intent);
    }

    public void handleSelection2(View view) {
        String resourceId = getResources().getResourceEntryName(view.getId());
        int currentArrayIndex = songCollection.searchSongById(resourceId);
        Log.d("temasek", "the current array position is : " + currentArrayIndex);
        sendDataToActivity2(currentArrayIndex);
    }
    public void sendDataToActivity2( int index) {
        Intent intent = new Intent(this, PlaySong.class);
        intent.putExtra("index", index);
        startActivity(intent);
    }


    public void handleSelection3(View view) {
        String resourceId = getResources().getResourceEntryName(view.getId());
        int currentArrayIndex = songCollection.searchSongById(resourceId);
        Log.d("temasek", "the current array position is : " + currentArrayIndex);
        sendDataToActivity3(currentArrayIndex);

    }
    public void sendDataToActivity3( int index) {
        Intent intent = new Intent(this, PlaySong.class);
        intent.putExtra("index", index);
        startActivity(intent);
    }

}
