package com.example.musicophileredo;

public class SongCollection {
    private Song songs[] = new Song[11];

    public SongCollection() {

        Song idgaf = new Song("S1004",
                "IDGAF",
                "Dua Lipa",
                "https://p.scdn.co/mp3-preview/b4c96641accfd7439cbba3485d149c7dce200708?cid=2afe87a64b0042dabf51f37318616965",
                3.63,
                R.drawable.idgaf);

        Song adoreYou = new Song("S1005",
                "Adore You",
                "Harry Styles",
                "https://p.scdn.co/mp3-preview/66131b40a641da2bef484eb00fc1f4f40f2c33c4?cid=2afe87a64b0042dabf51f37318616965",
                3.45,
                R.drawable.adore_you);

        Song toBeLoved = new Song("S1006",
                "To Be Loved",
                "Lizzo",
                "https://p.scdn.co/mp3-preview/5de13186b9510b7bf5d43c6724888462ebb5d085?cid=2afe87a64b0042dabf51f37318616965",
                3.12,
                R.drawable.to_be_loved);

        Song musicForASushiRestaurant = new Song("S1007",
                "Music For A Sushi Restaurant",
                "Harry Styles",
                "https://p.scdn.co/mp3-preview/b362f060e5b9261aca193c58e694b1f097d2cd41?cid=2afe87a64b0042dabf51f37318616965",
                3.23,
                R.drawable.music_for_a_sushi_restaurant);

        Song lateNightTalking = new Song("S1008",
                "Late Night Talking",
                "Harry Styles",
                "https://p.scdn.co/mp3-preview/ab3568a72e1c016308c263854dc307251ce33a2b?cid=2afe87a64b0042dabf51f37318616965",
                2.97,
                R.drawable.late_night_talking);

        Song grapejuice = new Song("S1009",
                "Grapejuice",
                "Harry Styles",
                "https://p.scdn.co/mp3-preview/71e626d72bda1f0fd57e5405105d1db313b0c495?cid=2afe87a64b0042dabf51f37318616965",
                3.2,
                R.drawable.grapejuice);

        Song asItWas = new Song("S10010",
                "As it was",
                "Harry Styles",
                "https://p.scdn.co/mp3-preview/f0c2adc40766cd8c1ec3f2bc6e1cc293a77ba684?cid=2afe87a64b0042dabf51f37318616965",
                2.79,
                R.drawable.as_it_was);

        Song letMe = new Song("S10011",
                "Let Me",
                "Zayn Malik",
                "https://p.scdn.co/mp3-preview/68226ec377af584e49fb492034a7f622cc74e45a?cid=2afe87a64b0042dabf51f37318616965",
                3.09,
                R.drawable.let_me);

        Song natural = new Song("S10012",
                "Natural",
                "Zayn Malik",
                "https://p.scdn.co/mp3-preview/81d810d0d12ed85b196c0b87176f97e0651cafa2?cid=2afe87a64b0042dabf51f37318616965",
                3.22,
                R.drawable.natural);

        Song backToLife = new Song("S10013",
                "Back to life",
                "Zayn Malik",
                "https://p.scdn.co/mp3-preview/5acb908b44951f9915775c1b12cd39b239ac3171?cid=2afe87a64b0042dabf51f37318616965",
                3.26,
                R.drawable.back_to_life);

        Song common = new Song("S10014",
                "Common",
                "Zayn Malik",
                "https://p.scdn.co/mp3-preview/27506e9560f9a98193e749b17fe0142202bbda8b?cid=2afe87a64b0042dabf51f37318616965",
                3.88,
                R.drawable.common);

        songs[0] = idgaf;
        songs[1] = adoreYou;
        songs[2] = toBeLoved;
        songs[3] = musicForASushiRestaurant;
        songs[4] = lateNightTalking;
        songs[5] = grapejuice;
        songs[6] = asItWas;
        songs[7] = letMe;
        songs[8] = natural;
        songs[9] = backToLife;
        songs[10] = common;


    }
    public Song getCurrentSong(int currentSongId){
        return songs[currentSongId];
    }

    public int searchSongById(String id) {

        for(int index=0; index < songs.length; index++)
        {
            Song tempSong = songs[index];
            if(tempSong.getId().equals(id)){
                return index;
            }
        }
        return -1;

    }

    public int getNextSong(int currentSongIndex){
        if (currentSongIndex >= songs.length - 1)
        {
            return currentSongIndex;
        }
        else {
            return currentSongIndex +1;
        }
    }

    public int getPrevSong(int currentSongIndex){
        if (currentSongIndex <= 0){
            return currentSongIndex;
        }
        else{
            return currentSongIndex - 1;
        }
    }
}

