package com.example.musicophileredo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class Album1Activity extends AppCompatActivity {
    SongCollection songCollection = new SongCollection();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_album1);
    }

    public void handleSelection(View view) {
        String resourceId = getResources().getResourceEntryName(view.getId());
        int currentArrayIndex = songCollection.searchSongById(resourceId);
        Log.d("temasek", "the id of the pressed ImageButton is : " + resourceId);

        Bundle songData = this.getIntent().getExtras();
        int index = songData.getInt("index");
        Log.d("temasek", "we rx :" + index);

       
    }
}